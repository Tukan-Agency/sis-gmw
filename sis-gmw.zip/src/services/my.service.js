module.exports = {
	MyService
};