 

	module.exports = {
		get: async (req, res) => {
			console.log('My service');
	},
};